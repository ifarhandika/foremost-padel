export const NAV_LINKS = [
  {
    href: "/",
    key: "club",
    label: "Club",
  },
  {
    href: "/tournament",
    key: "tournament",
    label: "Tournament",
  },
  {
    href: "/investor",
    key: "investor",
    label: "Investor",
  },
  {
    href: "/find-us",
    key: "findus",
    label: "Find Us",
  },
]
