globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/638d90a565d71fdc.js",
      "static/chunks/turbopack-6f000b492354bb96.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/638d90a565d71fdc.js",
      "static/chunks/turbopack-edfcefc674cdd22d.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/3eba6931cad880e3.js",
    "static/chunks/47f477e3d2ef265b.js",
    "static/chunks/7880f8283a6f3daf.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-32f19036fb4743bb.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];