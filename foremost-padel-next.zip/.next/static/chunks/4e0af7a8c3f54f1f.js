__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/638d90a565d71fdc.js",
  "static/chunks/turbopack-edfcefc674cdd22d.js"
])
