__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/638d90a565d71fdc.js",
  "static/chunks/turbopack-6f000b492354bb96.js"
])
